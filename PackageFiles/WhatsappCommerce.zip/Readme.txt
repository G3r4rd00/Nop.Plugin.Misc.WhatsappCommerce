1. 'Nop.Plugin.Misc.WhatsappCommerce' directory contains source code.
2. 'Misc.WhatsappCommerce' contains binaries. Just drop it into \Plugins directory on your server.